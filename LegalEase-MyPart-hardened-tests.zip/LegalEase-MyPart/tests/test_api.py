from fastapi.testclient import TestClient

from legalEaseAPI import routes
from legalEaseAPI.main import app


client = TestClient(app)


def test_health_returns_ok():
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_generate_returns_generated_document(monkeypatch):
    class FakeGenerator:
        def generate_document(self, document_type, parties, terms, dates):
            assert document_type == "NDA"
            assert parties == "Alice and Bob"
            assert terms == "Keep information confidential"
            assert dates == "2026-09-26"
            return "1. Confidentiality\n\nThe parties agree to keep information confidential."

    monkeypatch.setattr(routes, "get_generator", lambda: FakeGenerator())

    response = client.post(
        "/generate",
        json={
            "document_type": "NDA",
            "parties": "Alice and Bob",
            "terms": "Keep information confidential",
            "dates": "2026-09-26",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "document": "1. Confidentiality\n\nThe parties agree to keep information confidential."
    }


def test_generate_rejects_missing_required_field():
    response = client.post(
        "/generate",
        json={
            "document_type": "NDA",
            "parties": "Alice and Bob",
            "terms": "Keep information confidential",
        },
    )

    assert response.status_code == 422


def test_generate_maps_generator_error_to_server_error(monkeypatch):
    def failing_generator():
        raise RuntimeError("Document generation failed")

    monkeypatch.setattr(routes, "get_generator", failing_generator)

    response = client.post(
        "/generate",
        json={
            "document_type": "NDA",
            "parties": "Alice and Bob",
            "terms": "Keep information confidential",
            "dates": "2026-09-26",
        },
    )

    assert response.status_code == 500
    assert response.json() == {"detail": "Document generation failed"}