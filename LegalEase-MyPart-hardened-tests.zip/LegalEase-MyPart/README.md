# LegalEase — My Part (Activity 1.3 to Activity 3.1)

This is just the **backend + AI core** portion — environment setup,
document generation logic, and the FastAPI backend (main.py + routes.py).
The Streamlit frontend (Milestone 4) is a separate teammate's part and is
**not included** here.

## Structure

```
LegalEase-MyPart/
├── ai_core/
│   ├── gemini_generator.py   # Activity 2.1 — Gemini API call
│   └── generator.py          # Activity 2.1 — sanitize_text, format_docx, format_pdf, format_html_preview
├── legalEaseAPI/
│   ├── main.py                # Activity 3.1 — FastAPI app, root route, include router
│   ├── routes.py              # Activity 2.2 / 3.2 — DocumentRequest model, /generate endpoint
│   └── config.py              # env config
├── requirements.txt
└── .env.example
```

## Setup

```bash
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # macOS/Linux

pip install -r requirements.txt
```

Copy `.env.example` to `.env` and add your Gemini key (get one free at
https://aistudio.google.com/apikey):

```
GEMINI_API_KEY=your_actual_key_here
```

For local Streamlit development, the API allows only these frontend origins
by default:

```
http://localhost:8501
http://127.0.0.1:8501
```

Set `BACKEND_ALLOWED_ORIGINS` to a comma-separated list of exact trusted
frontend origins when deploying. Do not use `*` when the API is exposed
outside local development.

## Run the backend only

```bash
uvicorn legalEaseAPI.main:app --reload --port 8000
```

## Run the backend tests

From the `LegalEase-MyPart` directory:

```bash
pytest
```

## Test it (no frontend needed)

- Open `http://localhost:8000/` → should show a welcome message.
- Open `http://localhost:8000/health` → should return `{"status": "ok"}`.
- Test `/generate` with a POST request, e.g. using the FastAPI docs UI at
  `http://localhost:8000/docs` — try the `POST /generate` endpoint with:
  ```json
  {
    "document_type": "NDA",
    "parties": "A, B",
    "terms": "Confidentiality must be maintained; Term of 2 years",
    "dates": "April 15, 2025"
  }
  ```
  It should return a generated legal document as JSON.

Your teammate's `frontend/app.py` will call this same `/generate` endpoint
once both parts are combined.
