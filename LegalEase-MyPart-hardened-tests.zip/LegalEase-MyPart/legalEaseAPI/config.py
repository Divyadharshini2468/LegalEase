"""
legalEaseAPI/config.py

Centralized configuration loaded from environment variables / .env.
"""

import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL_NAME = os.getenv("GEMINI_MODEL_NAME", "gemini-1.5-pro")

BACKEND_HOST = os.getenv("BACKEND_HOST", "0.0.0.0")
BACKEND_PORT = int(os.getenv("BACKEND_PORT", "8000"))

BACKEND_URL = os.getenv("BACKEND_URL", f"http://localhost:{BACKEND_PORT}")

# Keep the API reachable from the local Streamlit development server by
# default, while requiring deployment environments to opt into their own
# frontend origins explicitly.
_default_allowed_origins = (
    "http://localhost:8501,http://127.0.0.1:8501"
)
BACKEND_ALLOWED_ORIGINS = [
    origin.strip().rstrip("/")
    for origin in os.getenv(
        "BACKEND_ALLOWED_ORIGINS", _default_allowed_origins
    ).split(",")
    if origin.strip()
]

if not GEMINI_API_KEY:
    # Not raising here so the API can still boot and report a clear
    # error from the /generate endpoint instead of crashing on import.
    print(
        "[config] WARNING: GEMINI_API_KEY is not set. "
        "Set it in a .env file before calling /generate."
    )
