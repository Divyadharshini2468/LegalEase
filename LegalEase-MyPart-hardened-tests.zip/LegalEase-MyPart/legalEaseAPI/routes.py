"""
legalEaseAPI/routes.py

API routes for LegalEase: accepts document requests from the
Streamlit frontend and returns Gemini-generated legal text.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ai_core.gemini_generator import GeminiDocumentGenerator

router = APIRouter()

# Instantiated lazily so a missing API key doesn't crash the whole app at import time.
_generator = None


def get_generator() -> GeminiDocumentGenerator:
    global _generator
    if _generator is None:
        _generator = GeminiDocumentGenerator()
    return _generator


class DocumentRequest(BaseModel):
    document_type: str = Field(..., description="e.g. 'Freelance Work Contract'")
    parties: str = Field(..., description="Names/roles of everyone involved")
    terms: str = Field(..., description="Semicolon-separated clauses")
    dates: str = Field(..., description="Effective date of the document")


@router.get("/health")
def health_check():
    return {"status": "ok"}


@router.post("/generate")
def generate_legal_document(request: DocumentRequest):
    try:
        generator = get_generator()
        response = generator.generate_document(
            request.document_type,
            request.parties,
            request.terms,
            request.dates,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {"document": response}
