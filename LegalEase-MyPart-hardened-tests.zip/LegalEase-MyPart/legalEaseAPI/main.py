"""
legalEaseAPI/main.py

FastAPI application entrypoint for LegalEase.
Run with:  uvicorn legalEaseAPI.main:app --reload
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from legalEaseAPI.config import BACKEND_ALLOWED_ORIGINS
from legalEaseAPI.routes import router

app = FastAPI(title="LegalEase - AI Legal Document Generator")

# Allow only explicitly configured frontend origins. The local defaults cover
# Streamlit's standard development port; deployments should set
# BACKEND_ALLOWED_ORIGINS to a comma-separated list of trusted origins.
app.add_middleware(
    CORSMiddleware,
    allow_origins=BACKEND_ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Accept", "Content-Type"],
)

app.include_router(router)


@app.get("/")
def home():
    return {"message": "Welcome to LegalEase AI Legal Document Generator API"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
