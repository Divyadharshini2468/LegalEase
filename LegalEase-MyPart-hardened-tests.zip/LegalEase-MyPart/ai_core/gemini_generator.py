"""
ai_core/gemini_generator.py

Wraps the Google Generative AI (Gemini) SDK and turns structured
document requests into a full legal-document draft.
"""

import os
import logging

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

DEFAULT_MODEL_NAME = "gemini-1.5-pro"


class GeminiDocumentGenerator:
    """Generates legal document drafts using Google's Gemini model."""

    def __init__(self, model_name: str = DEFAULT_MODEL_NAME):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError(
                "GEMINI_API_KEY is not set. Add it to your .env file or "
                "environment variables before starting the app."
            )

        genai.configure(api_key=api_key)
        self.model_name = model_name
        self.model = genai.GenerativeModel(model_name)

    def _build_prompt(
        self,
        document_type: str,
        parties: str,
        terms: str,
        dates: str,
    ) -> str:
        """Builds a structured prompt describing the document to draft."""
        return (
            f"You are an expert legal drafter. Generate a comprehensive, "
            f"formally structured legal document titled '{document_type}'.\n\n"
            f"Involved parties: {parties}\n"
            f"Effective date: {dates}\n"
            f"Terms and conditions (each item separated by a semicolon): {terms}\n\n"
            "Requirements:\n"
            "- Use clear section headings (e.g. '1. Services', '2. Term and "
            "Termination', '3. Payment', '4. Confidentiality', etc.)\n"
            "- Reflect every term supplied above as its own numbered clause.\n"
            "- Include standard boilerplate clauses appropriate for this "
            "document type (governing law, entire agreement, severability, "
            "signature block) even if not explicitly requested.\n"
            "- Where a concrete detail (address, amount, state) was not "
            "provided, use a clearly bracketed placeholder like "
            "[Dollar Amount] or [State].\n"
            "- Write in formal legal English, and avoid explanations or "
            "commentary outside the document itself.\n"
        )

    def generate_document(
        self,
        document_type: str,
        parties: str,
        terms: str,
        dates: str,
    ) -> str:
        """
        Calls the Gemini model and returns the generated legal document
        as plain text.
        """
        prompt = self._build_prompt(document_type, parties, terms, dates)

        try:
            response = self.model.generate_content(prompt)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Gemini generation failed")
            raise RuntimeError(f"Document generation failed: {exc}") from exc

        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")

        return text.strip()
