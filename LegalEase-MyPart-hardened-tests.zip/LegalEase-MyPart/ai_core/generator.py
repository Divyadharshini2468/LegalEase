"""
ai_core/generator.py

Formatting utilities that turn raw AI-generated text into
clean, exportable TXT / DOCX / PDF / HTML output.
"""

import os
import re
import html

from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from fpdf import FPDF, XPos, YPos

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOGO_PATH = os.path.join(BASE_DIR, "Image", "Logo.png")


def _logo_available() -> bool:
    """Return whether the optional branding image is available."""
    return os.path.isfile(LOGO_PATH)


def sanitize_text(text: str) -> str:
    """Removes special/typographic characters for clean formatting."""
    if not text:
        return ""
    replacements = {
        "\u2018": "'", "\u2019": "'",
        "\u201c": '"', "\u201d": '"',
        "\u2013": "-", "\u2014": "-",
        "\u2026": "...",
    }
    for bad, good in replacements.items():
        text = text.replace(bad, good)
    # Strip any leftover markdown bold markers left by the model
    text = text.replace("**", "")
    return text.strip()


def _split_sections(text: str):
    """Splits generated text into (heading, body) blocks by numbered headings."""
    lines = text.split("\n")
    sections = []
    current_heading = None
    current_body = []

    heading_pattern = re.compile(r"^(#{1,3}\s*)?\d+\.\s+.+")

    for line in lines:
        stripped = line.strip()
        if heading_pattern.match(stripped):
            if current_heading is not None or current_body:
                sections.append((current_heading, "\n".join(current_body).strip()))
            current_heading = stripped.lstrip("#").strip()
            current_body = []
        else:
            current_body.append(line)

    if current_heading is not None or current_body:
        sections.append((current_heading, "\n".join(current_body).strip()))

    return sections


def format_docx(text: str, doc_type: str) -> bytes:
    """Builds a formatted .docx file with logo, headings and footer."""
    text = sanitize_text(text)
    document = Document()

    style = document.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(11)

    if _logo_available():
        header_para = document.add_paragraph()
        header_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = header_para.add_run()
        run.add_picture(LOGO_PATH, width=Inches(1.3))

    title = document.add_heading(doc_type or "Legal Document", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    sections = _split_sections(text)
    if not sections:
        document.add_paragraph(text)
    else:
        for heading, body in sections:
            if heading:
                document.add_heading(heading, level=2)
            if body:
                for para in body.split("\n\n"):
                    if para.strip():
                        document.add_paragraph(para.strip())

    document.add_paragraph()
    footer_para = document.add_paragraph("LegalEase Inc. | contact@legalease.com | All Rights Reserved.")
    footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in footer_para.runs:
        run.italic = True
        run.font.size = Pt(8)

    import io
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


class LegalPDF(FPDF):
    """FPDF subclass with a branded header and footer."""

    def header(self):
        if _logo_available():
            self.image(LOGO_PATH, x=self.w / 2 - 10, y=8, w=20)
            self.ln(22)
        else:
            self.ln(10)
        self.set_font("Helvetica", "B", 14)
        self.cell(0, 10, "LegalEase", align="C")
        self.ln(12)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.cell(0, 10, "LegalEase Inc. | contact@legalease.com | All Rights Reserved.", align="C")


def format_pdf(text: str, doc_type: str) -> bytes:
    """Builds a branded PDF with header/footer and bullet-style terms."""
    text = sanitize_text(text)

    pdf = LegalPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 13)
    pdf.multi_cell(
        0,
        8,
        doc_type or "Legal Document",
        align="C",
        new_x=XPos.LMARGIN,
        new_y=YPos.NEXT,
    )
    pdf.ln(4)

    sections = _split_sections(text)
    pdf.set_font("Helvetica", "", 11)

    if not sections:
        pdf.multi_cell(0, 6, text)
    else:
        for heading, body in sections:
            if heading:
                pdf.set_font("Helvetica", "B", 11)
                pdf.multi_cell(
                    0,
                    7,
                    heading,
                    new_x=XPos.LMARGIN,
                    new_y=YPos.NEXT,
                )
                pdf.set_font("Helvetica", "", 11)
            if body:
                for line in body.split("\n"):
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith(("-", "*", "•")):
                        pdf.multi_cell(
                            0,
                            6,
                            f"  - {line.lstrip('-*• ').strip()}",
                            new_x=XPos.LMARGIN,
                            new_y=YPos.NEXT,
                        )
                    else:
                        pdf.multi_cell(
                            0,
                            6,
                            line,
                            new_x=XPos.LMARGIN,
                            new_y=YPos.NEXT,
                        )
            pdf.ln(2)

    return bytes(pdf.output(dest="S"))


def format_html_preview(text: str) -> str:
    """Converts raw text into a styled HTML block for inline Streamlit preview."""
    text = sanitize_text(text)
    escaped = html.escape(text)

    lines = escaped.split("\n")
    html_lines = []
    heading_pattern = re.compile(r"^\d+\.\s+.+")

    for line in lines:
        stripped = line.strip()
        if not stripped:
            html_lines.append("<br>")
        elif heading_pattern.match(stripped):
            html_lines.append(f"<h4 style='margin-top:16px;color:#e2c275;'>{stripped}</h4>")
        elif stripped.startswith(("-", "*", "•")):
            html_lines.append(f"<li>{stripped.lstrip('-*• ').strip()}</li>")
        else:
            html_lines.append(f"<p style='margin:4px 0;'>{stripped}</p>")

    return "\n".join(html_lines)
